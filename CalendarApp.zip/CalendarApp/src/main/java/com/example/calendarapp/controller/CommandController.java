package com.example.calendarapp.controller;

import com.example.calendarapp.model.BaseCalendar;
import com.example.calendarapp.model.Event;

import java.io.File;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.Scanner;

/**
 * Handles command-line inputs and delegates event-related actions
 * to the EventController. Acts as the primary interface for user interaction
 * with calendar functionalities such as viewing dates and managing events.
 */
public class CommandController {

    /** File path to save and load calendar events. */
    private static final File calendarFile = getUserDataFile();

    /** The calendar model for managing events. */
    private final BaseCalendar calendar;

    /** Handles user commands related to events (add/edit/delete/etc). */
    private final EventController eventController;

    /** Scanner for reading user input interactively. */
    private final Scanner scanner = new Scanner(System.in);

    /**
     * Constructs a CommandController and initializes its calendar and event controller.
     */
    public CommandController() {
        this.calendar = new BaseCalendar(calendarFile);
        this.eventController = new EventController(calendar, calendarFile);
    }

    /**
     * Displays a welcome message and a list of available CLI commands.
     */
    public void printWelcome() {
        System.out.println("Welcome to CalendarApp CLI\n" +
            "Commands:\n" +
            "\tview-day | view-week | view-month\n" +
            "\tnext-month | prev-month | next-week | prev-week\n" +
            "\tset-date dd/MM/yyyy\n" +
            "\tadd-event | edit-event | view-event\n" +
            "\tlist-events | events-by-category <CATEGORY>\n" +
            "\ttrack-time <CATEGORY> | delete-event\n" +
            "\texit");
    }

    /**
     * Prints a summary of events occurring from the current date until the end of the week.
     */
    public void printWeekSummary() {
        LocalDate today = calendar.getCurrentDate();
        LocalDate endOfWeek = today.with(DayOfWeek.SUNDAY);
        boolean found = false;
        System.out.println("\nUpcoming Events This Week:\n");
        for (Event e : calendar.getEvents()) {
            LocalDate date = e.getStart().toLocalDate();
            if (!date.isBefore(today) && !date.isAfter(endOfWeek)) {
                System.out.println("\t" + e + "\n");
                found = true;
            }
        }
        if (!found) System.out.println("\tNo events scheduled this week.\n");
    }

    /**
     * Parses the user's input command and executes the corresponding calendar action.
     *
     * @param input the raw command string entered by the user
     */
    public void handleCommand(String input) {
        try {
            switch (input) {
                case "view-day" -> System.out.println(calendar.viewDay());
                case "view-week" -> System.out.println(calendar.viewWeek());
                case "view-month" -> System.out.println(calendar.viewMonth());
                case "next-month" -> {
                    calendar.nextMonth();
                    System.out.println("Moved to next month.");
                }
                case "prev-month" -> {
                    calendar.previousMonth();
                    System.out.println("Moved to previous month.");
                }
                case "next-week" -> {
                    calendar.nextWeek();
                    System.out.println("Moved to next week.");
                }
                case "prev-week" -> {
                    calendar.previousWeek();
                    System.out.println("Moved to previous week.");
                }
                case "add-event" -> eventController.handleAddEvent();
                case "edit-event" -> promptAndHandleEditEvent();
                case "view-event" -> promptAndHandleViewEvent();
                case "list-events" -> eventController.handleListEvents();
                case "exit" -> eventController.handleExit();
                case "delete-event" -> eventController.handleDeleteEvent();
                default -> {
                    if (input.startsWith("edit-event ")) {
                        eventController.handleEditEvent(input);
                    } else if (input.startsWith("view-event ")) {
                        eventController.handleViewEvent(input);
                    } else if (input.startsWith("events-by-category")) {
                        eventController.handleEventsByCategory(input);
                    } else if (input.startsWith("track-time")) {
                        eventController.handleTrackTime(input);
                    } else if (input.startsWith("set-date")) {
                        eventController.handleSetDate(input);
                    } else {
                        System.out.println("Unknown command.");
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    /**
     * Prompts user for an event ID to edit.
     */
    private void promptAndHandleEditEvent() {
        System.out.print("Enter event ID to edit: ");
        String idInput = scanner.nextLine().trim();
        eventController.handleEditEvent("edit-event " + idInput);
    }

    /**
     * Prompts user for an event ID to view.
     */
    private void promptAndHandleViewEvent() {
        System.out.print("Enter event ID to view: ");
        String idInput = scanner.nextLine().trim();
        eventController.handleViewEvent("view-event " + idInput);
    }

    /**
     * Returns the file path for storing the calendar data in the user's home directory.
     *
     * @return File pointing to the application's data storage location.
     */
    private static File getUserDataFile() {
        String userHome = System.getProperty("user.home");
        File appDir = new File(userHome, ".calendarapp");
        if (!appDir.exists()) {
            appDir.mkdirs();
        }
        return new File(appDir, "calendar.csv");
    }
}

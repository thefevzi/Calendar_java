package com.example.calendarapp.controller;

import com.example.calendarapp.model.BaseCalendar;
import com.example.calendarapp.model.Event;
import com.example.calendarapp.model.Event.EventCategory;

import java.io.File;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

/**
 * Handles all event-related operations such as adding, editing, viewing, deleting,
 * listing, filtering, and tracking time spent on events.
 */
public class EventController {

    /** Calendar model for event management. */
    private final BaseCalendar calendar;

    /** File to which events are saved. */
    private final File calendarFile;

    /** Scanner used to read user input. */
    private final Scanner scanner = new Scanner(System.in);

    /** Formatter for date and time input/output. */
    private static final DateTimeFormatter DATE_TIME_FORMAT = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    /**
     * Constructs an EventController.
     *
     * @param calendar      the calendar model
     * @param file          the file to save and load calendar data
     */
    public EventController(BaseCalendar calendar, File file) {
        this.calendar = calendar;
        this.calendarFile = file;
    }

    /**
     * Handles adding a new event by prompting user input for event details.
     */
    public void handleAddEvent() {
        String title = promptNonEmpty("Title: ");
        String desc = promptNonEmpty("Description: ");
        EventCategory category = promptCategory("Category (WORK, HEALTH, SOCIAL, EDUCATION, OTHER): ");
        LocalDateTime start = promptDateTime("Start (dd/MM/yyyy HH:mm): ");
        LocalDateTime end = promptDateTime("End (dd/MM/yyyy HH:mm): ");
        while (end.isBefore(start)) {
            System.out.println("End time must be after start time.");
            end = promptDateTime("End (dd/MM/yyyy HH:mm): ");
        }
        String location = promptNonEmpty("Location: ");
        calendar.addEvent(new Event(title, desc, category, start, end, location));
        calendar.saveToCSV(calendarFile);
        System.out.println("Event added.");
    }

    /**
     * Handles editing an existing event by ID.
     *
     * @param input the user command containing the event ID
     */
    public void handleEditEvent(String input) {
        try {
            int id = Integer.parseInt(input.split(" ")[1]);
            Event e = calendar.getEventById(id);
            if (e == null) {
                System.out.println("Event not found.");
                return;
            }

            System.out.print("New title (blank to keep): ");
            String title = scanner.nextLine();
            System.out.print("New description (blank to keep): ");
            String desc = scanner.nextLine();
            System.out.print("New category (blank to keep): ");
            String catInput = scanner.nextLine();
            System.out.print("New start (dd/MM/yyyy HH:mm) (blank to keep): ");
            String startStr = scanner.nextLine();
            System.out.print("New end (dd/MM/yyyy HH:mm) (blank to keep): ");
            String endStr = scanner.nextLine();
            System.out.print("New location (blank to keep): ");
            String locStr = scanner.nextLine();

            calendar.editEvent(
                id,
                title.isEmpty() ? e.getTitle() : title,
                desc.isEmpty() ? e.getDescription() : desc,
                catInput.isEmpty() ? e.getCategory() : EventCategory.valueOf(catInput.toUpperCase()),
                startStr.isEmpty() ? e.getStart() : LocalDateTime.parse(startStr, DATE_TIME_FORMAT),
                endStr.isEmpty() ? e.getEnd() : LocalDateTime.parse(endStr, DATE_TIME_FORMAT),
                locStr.isEmpty() ? e.getLocation() : locStr
            );
            calendar.saveToCSV(calendarFile);
            System.out.println("Event updated.");
        } catch (Exception e) {
            System.out.println("Usage: edit-event <id>");
        }
    }

    /**
     * Displays the details of a specific event.
     *
     * @param input the user command containing the event ID
     */
    public void handleViewEvent(String input) {
        try {
            int id = Integer.parseInt(input.split(" ")[1]);
            Event e = calendar.getEventById(id);
            System.out.println(e != null ? e : "Event not found.");
        } catch (Exception e) {
            System.out.println("Usage: view-event <id>");
        }
    }

    /**
     * Lists all events currently in the calendar.
     */
    public void handleListEvents() {
        for (Event e : calendar.getEvents()) {
            System.out.println("\t" + e + "\n");
        }
    }

    /**
     * Lists events filtered by a specified category.
     *
     * @param input the user command including the category
     */
    public void handleEventsByCategory(String input) {
        try {
            String[] parts = input.split(" ");
            EventCategory category = EventCategory.valueOf(parts[1].toUpperCase());
            List<Event> events = calendar.getEventsByCategory(category);
            if (events.isEmpty()) {
                System.out.println("No events found.");
            } else {
                events.forEach(System.out::println);
            }
        } catch (Exception e) {
            System.out.println("Usage: events-by-category <CATEGORY>");
        }
    }

    /**
     * Displays total time spent on events in a given category.
     *
     * @param input the user command including the category
     */
    public void handleTrackTime(String input) {
        try {
            String[] parts = input.split(" ");
            EventCategory category = EventCategory.valueOf(parts[1].toUpperCase());
            long minutes = calendar.totalTimeByCategory(category);
            System.out.printf("Total time in %s: %d hours %d minutes\n", category, minutes / 60, minutes % 60);
        } catch (Exception e) {
            System.out.println("Usage: track-time <CATEGORY>");
        }
    }

    /**
     * Sets the calendar's current date.
     *
     * @param input the user command including the date
     */
    public void handleSetDate(String input) {
        try {
            String[] parts = input.split(" ");
            LocalDate date = LocalDate.parse(parts[1], DateTimeFormatter.ofPattern("dd/MM/yyyy"));
            calendar.setDate(date);
            System.out.println("Date set to " + date.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
        } catch (Exception e) {
            System.out.println("Usage: set-date dd/MM/yyyy");
        }
    }

    /**
     * Deletes an event by ID.
     */
    public void handleDeleteEvent() {
        try {
            System.out.print("Enter event ID to delete: ");
            int id = Integer.parseInt(scanner.nextLine().trim());
            if (calendar.deleteEvent(id)) {
                calendar.saveToCSV(calendarFile);
                System.out.println("Event deleted.");
            } else {
                System.out.println("Event not found.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid ID format.");
        }
    }

    /**
     * Saves the calendar to file and exits the application.
     */
    public void handleExit() {
        calendar.saveToCSV(calendarFile);
        System.out.println("Calendar saved. Goodbye!");
        System.exit(0);
    }

    /**
     * Prompts the user until they provide non-empty input.
     *
     * @param message the prompt message
     * @return a non-empty string
     */
    private String promptNonEmpty(String message) {
        String input;
        do {
            System.out.print(message);
            input = scanner.nextLine().trim();
            if (input.isEmpty()) System.out.println("This field cannot be empty.");
        } while (input.isEmpty());
        return input;
    }

    /**
     * Prompts the user to input a valid event category.
     *
     * @param message the prompt message
     * @return the selected EventCategory
     */
    private EventCategory promptCategory(String message) {
        while (true) {
            System.out.print(message);
            String input = scanner.nextLine().trim().toUpperCase();
            try {
                return EventCategory.valueOf(input);
            } catch (IllegalArgumentException e) {
                System.out.println("Invalid category. Choose from: WORK, HEALTH, SOCIAL, EDUCATION, OTHER.");
            }
        }
    }

    /**
     * Prompts the user to input a valid date and time.
     *
     * @param message the prompt message
     * @return the parsed LocalDateTime
     */
    private LocalDateTime promptDateTime(String message) {
        while (true) {
            System.out.print(message);
            String input = scanner.nextLine().trim();
            try {
                return LocalDateTime.parse(input, DATE_TIME_FORMAT);
            } catch (Exception e) {
                System.out.println("Invalid date/time. Use format dd/MM/yyyy HH:mm.");
            }
        }
    }
}

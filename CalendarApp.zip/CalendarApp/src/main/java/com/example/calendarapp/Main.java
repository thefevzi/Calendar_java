package com.example.calendarapp;
import com.example.calendarapp.controller.CalendarController;

public class Main {
    public static void main(String[] args) {
        CalendarController controller = new CalendarController();
        controller.run();
    }
}

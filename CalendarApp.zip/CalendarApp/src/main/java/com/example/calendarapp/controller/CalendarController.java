package com.example.calendarapp.controller;

import java.util.Scanner;

/**
 * The main controller class that initializes and starts the Calendar application.
 * It acts as the entry point and routes user input to the appropriate command handlers.
 */
public class CalendarController {

    /** Handles the processing of user commands. */
    private final CommandController commandController;

    /** Scanner object used for reading user input from the command line. */
    private final Scanner scanner = new Scanner(System.in);

    /**
     * Constructs a CalendarController and initializes the CommandController.
     */
    public CalendarController() {
        this.commandController = new CommandController();
    }

    /**
     * Starts the command-line interface loop.
     * Displays a welcome message and weekly summary, then continuously reads and processes user input.
     */
    public void run() {
        commandController.printWelcome();
        commandController.printWeekSummary();

        while (true) {
            System.out.print("> ");
            String input = scanner.nextLine().trim();
            commandController.handleCommand(input);
        }
    }
}

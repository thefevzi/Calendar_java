package com.example.calendarapp.controller;

import java.io.File;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

import com.example.calendarapp.model.BaseCalendar;
import com.example.calendarapp.model.Event;
import com.example.calendarapp.model.Event.EventCategory;

/**
 * Handles user interaction with the calendar.
 */
public class CalendarController {

    private final BaseCalendar calendar;
    private final Scanner scanner = new Scanner(System.in);
    private static final File calendarFile = new File("data/calendar.csv");
    private static final DateTimeFormatter DATE_TIME_FORMAT = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    /**
     * Initializes the calendar.
     */
    public CalendarController() {
        calendar = new BaseCalendar();
    }

    /**
     * Starts the CLI loop and awaits user command.
     */
    public void run() {
        printWelcome();
        printWeekSummary();

        while (true) {
            System.out.print("> ");
            String input = scanner.nextLine().trim();
            handleCommand(input);
        }
    }

    /**
     * Displays the welcome message and available commands.
     */
    private void printWelcome() {
        System.out.println("Welcome to CalendarApp CLI\n" +
            "Commands:\n" +
            "\tview-day | view-week | view-month\n" +
            "\tnext-month | prev-month | next-week | prev-week\n" +
            "\tset-date dd/MM/yyyy\n" +
            "\tadd-event | edit-event <id> | view-event <id>\n" +
            "\tlist-events | events-by-category <CATEGORY>\n" +
            "\ttrack-time <CATEGORY> | exit");
    }

    /**
     * Prints a summary of upcoming events for the current week.
     */
    private void printWeekSummary() {
        LocalDate today = calendar.getCurrentDate();
        LocalDate endOfWeek = today.with(DayOfWeek.SUNDAY);
        boolean found = false;
        System.out.println("\nUpcoming Events This Week:\n");
        for (Event e : calendar.getEvents()) {
            LocalDate date = e.getStart().toLocalDate();
            if (!date.isBefore(today) && !date.isAfter(endOfWeek)) {
                System.out.println("\t" + e + "\n");
                found = true;
            }
        }
        if (!found) System.out.println("\tNo events scheduled this week.\n");
    }

    /**
     * Parses and executes a given command string.
     * 
     * @param input The command input given by the user.
     */
    private void handleCommand(String input) {
        try {
            if (input.equals("view-day")) System.out.println(calendar.viewDay());
            else if (input.equals("view-week")) System.out.println(calendar.viewWeek());
            else if (input.equals("view-month")) System.out.println(calendar.viewMonth());
            else if (input.equals("next-month")) { calendar.nextMonth(); System.out.println("Moved to next month."); }
            else if (input.equals("prev-month")) { calendar.previousMonth(); System.out.println("Moved to previous month."); }
            else if (input.equals("next-week")) { calendar.nextWeek(); System.out.println("Moved to next week."); }
            else if (input.equals("prev-week")) { calendar.previousWeek(); System.out.println("Moved to previous week."); }
            else if (input.equals("add-event")) handleAddEvent();
            else if (input.startsWith("edit-event")) handleEditEvent(input);
            else if (input.startsWith("view-event")) handleViewEvent(input);
            else if (input.equals("list-events")) handleListEvents();
            else if (input.startsWith("events-by-category")) handleEventsByCategory(input);
            else if (input.startsWith("track-time")) handleTrackTime(input);
            else if (input.startsWith("set-date")) handleSetDate(input);
            else if (input.equals("exit")) handleExit();
            else System.out.println("Unknown command.");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    /**
     * Prompts the user for event details and adds a new event to the calendar.
     */
    private void handleAddEvent() {
        try {
            System.out.print("Title: ");
            String title = scanner.nextLine();

            System.out.print("Description: ");
            String desc = scanner.nextLine();

            System.out.print("Category (WORK, HEALTH, SOCIAL, EDUCATION, OTHER): ");
            EventCategory category = EventCategory.valueOf(scanner.nextLine().toUpperCase());

            System.out.print("Start (dd/MM/yyyy HH:mm): ");
            LocalDateTime start = LocalDateTime.parse(scanner.nextLine(), DATE_TIME_FORMAT);

            System.out.print("End (dd/MM/yyyy HH:mm): ");
            LocalDateTime end = LocalDateTime.parse(scanner.nextLine(), DATE_TIME_FORMAT);

            System.out.print("Location: ");
            String location = scanner.nextLine();

            calendar.addEvent(new Event(title, desc, category, start, end, location));
            calendar.saveToCSV(calendarFile);
            System.out.println("Event added.");
        } catch (Exception e) {
            System.out.println("Invalid input. Please use format dd/MM/yyyy HH:mm");
        }
    }

    /**
     * Prompts the user to edit an existing event by ID.
     * 
     * @param input The full command string, including the event ID.
     */
    private void handleEditEvent(String input) {
        try {
            int id = Integer.parseInt(input.split(" ")[1]);
            Event e = calendar.getEventById(id);
            if (e == null) { System.out.println("Event not found."); return; }

            System.out.print("New title (blank to keep): ");
            String title = scanner.nextLine();
            if (title.isEmpty()) title = e.getTitle();

            System.out.print("New description (blank to keep): ");
            String desc = scanner.nextLine();
            if (desc.isEmpty()) desc = e.getDescription();

            System.out.print("New category (blank to keep): ");
            String catInput = scanner.nextLine();
            EventCategory category = catInput.isEmpty() ? e.getCategory() : EventCategory.valueOf(catInput.toUpperCase());

            System.out.print("New start (dd/MM/yyyy HH:mm) (blank to keep): ");
            String startStr = scanner.nextLine();
            LocalDateTime start = startStr.isEmpty() ? e.getStart() : LocalDateTime.parse(startStr, DATE_TIME_FORMAT);

            System.out.print("New end (dd/MM/yyyy HH:mm) (blank to keep): ");
            String endStr = scanner.nextLine();
            LocalDateTime end = endStr.isEmpty() ? e.getEnd() : LocalDateTime.parse(endStr, DATE_TIME_FORMAT);

            System.out.print("New location (blank to keep): ");
            String locStr = scanner.nextLine();
            String location = locStr.isEmpty() ? e.getLocation() : locStr;

            calendar.editEvent(id, title, desc, category, start, end, location);
            calendar.saveToCSV(calendarFile);
            System.out.println("Event updated.");
        } catch (Exception e) {
            System.out.println("Usage: edit-event <id>");
        }
    }

    /**
     * Displays a specific event given by its ID.
     * 
     * @param input The command containing the event ID.
     */
    private void handleViewEvent(String input) {
        try {
            int id = Integer.parseInt(input.split(" ")[1]);
            Event e = calendar.getEventById(id);
            System.out.println(e != null ? e : "Event not found.");
        } catch (Exception e) {
            System.out.println("Usage: view-event <id>");
        }
    }

    /**
     * Displays all events in the calendar.
     */
    private void handleListEvents() {
        for (Event e : calendar.getEvents()) {
            System.out.println("\t" + e + "\n");
        }
    }

    /**
     * Filters and displays events by category.
     * 
     * @param input The command string containing the category.
     */
    private void handleEventsByCategory(String input) {
        try {
            String[] parts = input.split(" ");
            if (parts.length < 2) throw new IllegalArgumentException();
            EventCategory category = EventCategory.valueOf(parts[1].toUpperCase());
            List<Event> events = calendar.getEventsByCategory(category);
            if (events.isEmpty()) {
                System.out.println("No events found.");
            } else {
                for (Event e : events) {
                    System.out.println(e);
                }
            }
        } catch (Exception e) {
            System.out.println("Usage: events-by-category <CATEGORY>");
        }
    }

    /**
     * Calculates and prints the total time spent in events of a specific category.
     * 
     * @param input The command string containing the category.
     */
    private void handleTrackTime(String input) {
        try {
            String[] parts = input.split(" ");
            if (parts.length < 2) throw new IllegalArgumentException();
            EventCategory category = EventCategory.valueOf(parts[1].toUpperCase());
            long minutes = calendar.totalTimeByCategory(category);
            System.out.printf("Total time in %s: %d hours %d minutes\n", category, minutes / 60, minutes % 60);
        } catch (Exception e) {
            System.out.println("Usage: track-time <CATEGORY>");
        }
    }

    /**
     * Sets the current date in the calendar.
     * 
     * @param input The command string containing the date.
     */
    private void handleSetDate(String input) {
        try {
            String[] parts = input.split(" ");
            if (parts.length < 2) throw new IllegalArgumentException();
            DateTimeFormatter dateOnlyFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            LocalDate date = LocalDate.parse(parts[1], dateOnlyFormatter);
            calendar.setDate(date);
            System.out.println("Date set to " + date.format(dateOnlyFormatter));
        } catch (Exception e) {
            System.out.println("Usage: set-date dd/MM/yyyy");
        }
    }

    /**
     * Saves the calendar and exits the program.
     */
    private void handleExit() {
        calendar.saveToCSV(calendarFile);
        System.out.println("Calendar saved. Goodbye!");
        System.exit(0);
    }
}

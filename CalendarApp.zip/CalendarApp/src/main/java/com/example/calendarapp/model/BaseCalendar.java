package com.example.calendarapp.model;

import java.io.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import com.example.calendarapp.model.Event.EventCategory;

/**
 * Represents a basic calendar system that manages events, provides views by day,
 * week, and month, and supports saving/loading from CSV files.
 */
public class BaseCalendar {

    private static final String ANSI_RESET = "\u001B[0m";
    private static final String ANSI_RED = "\u001B[31m";
    private static final String ANSI_BLUE = "\u001B[34m";

    private LocalDate currentDate;
    private List<Event> events = new ArrayList<>();

    /**
     * Constructs a BaseCalendar by loading events from a CSV file.
     *
     * @param csvFile The file to load events from.
     */
    public BaseCalendar(File csvFile) {
        this.currentDate = LocalDate.now();

        File parentDir = csvFile.getParentFile();
        if (parentDir != null && !parentDir.exists()) {
            parentDir.mkdirs();
        }

        if (csvFile.exists()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(csvFile))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    events.add(Event.fromCSV(line));
                }
            } catch (IOException e) {
                System.err.println("Failed to load events: " + e.getMessage());
            }
        }
    }

    /**
     * Constructs a BaseCalendar with the current date and no preloaded events.
     */
    public BaseCalendar() {
        this.currentDate = LocalDate.now();
    }

    /**
     * Sets the current date of the calendar.
     *
     * @param date The date to set.
     */
    public void setDate(LocalDate date) {
        this.currentDate = date;
    }

    /**
     * Gets the current date of the calendar.
     *
     * @return The current LocalDate.
     */
    public LocalDate getCurrentDate() {
        return this.currentDate;
    }

    /**
     * Adds a new event to the calendar.
     *
     * @param event The event to add.
     */
    public void addEvent(Event event) {
        events.add(event);
    }

    /**
     * Gets all events in the calendar.
     *
     * @return A list of events.
     */
    public List<Event> getEvents() {
        return events;
    }

    /**
     * Retrieves all events belonging to a specific category.
     *
     * @param category The category to filter by.
     * @return A list of events in the specified category.
     */
    public List<Event> getEventsByCategory(EventCategory category) {
        List<Event> filtered = new ArrayList<>();
        for (Event e : events) {
            if (e.getCategory() == category) {
                filtered.add(e);
            }
        }
        return filtered;
    }

    /**
     * Calculates the total time spent on events in a specific category.
     *
     * @param category The category to summarize.
     * @return Total time in minutes.
     */
    public long totalTimeByCategory(EventCategory category) {
        long totalMinutes = 0;
        for (Event e : getEventsByCategory(category)) {
            Duration duration = Duration.between(e.getStart(), e.getEnd());
            totalMinutes += duration.toMinutes();
        }
        return totalMinutes;
    }

    /**
     * Finds an event by its unique ID.
     *
     * @param id The ID of the event.
     * @return The event if found; otherwise, null.
     */
    public Event getEventById(int id) {
        for (Event e : events) {
            if (e.getId() == id) return e;
        }
        return null;
    }

    /**
     * Edits an existing event with new details.
     *
     * @param id       Event ID.
     * @param title    New title.
     * @param desc     New description.
     * @param category New category.
     * @param start    New start time.
     * @param end      New end time.
     * @param location New location.
     * @return True if update succeeded, false otherwise.
     */
    public boolean editEvent(int id, String title, String desc, EventCategory category, LocalDateTime start, LocalDateTime end, String location) {
        for (int i = 0; i < events.size(); i++) {
            if (events.get(i).getId() == id) {
                events.set(i, new Event(id, title, desc, category, start, end, location));
                return true;
            }
        }
        return false;
    }

    /**
     * Saves all events in the calendar to a CSV file.
     *
     * @param file The file to save to.
     */
    public void saveToCSV(File file) {
        File parentDir = file.getParentFile();
        if (parentDir != null && !parentDir.exists()) {
            parentDir.mkdirs(); 
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            for (Event e : events) {
                writer.write(e.toCSV());
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Failed to save events: " + e.getMessage());
        }
    }

    /**
     * Displays all events scheduled for the current day.
     *
     * @return A formatted string representing the daily view.
     */
    public String viewDay() {
        StringBuilder sb = new StringBuilder();
        sb.append("==== Daily View ====\n");
        sb.append("Date: ").append(ANSI_BLUE).append(currentDate.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))).append(ANSI_RESET).append("\n\n");

        boolean hasEvents = false;
        for (Event event : events) {
            if (event.getStart().toLocalDate().equals(currentDate)) {
                sb.append(event).append("\n");
                hasEvents = true;
            }
        }

        if (!hasEvents) {
            sb.append("No events scheduled for this day.\n");
        }

        return sb.toString();
    }

    /**
     * Displays a summary of events for the current week.
     *
     * @return A formatted string representing the weekly view.
     */
    public String viewWeek() {
        LocalDate startOfWeek = currentDate.with(DayOfWeek.MONDAY);
        LocalDate endOfWeek = startOfWeek.plusDays(6);
        StringBuilder sb = new StringBuilder();
        sb.append("==== Weekly View ====\n");
        sb.append("Week: ").append(startOfWeek.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")))
        .append(" to ").append(endOfWeek.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")))
        .append("\n\n");

        for (int i = 0; i < 7; i++) {
            LocalDate day = startOfWeek.plusDays(i);
            String label = day.getDayOfWeek().toString().substring(0, 3);
            String dateStr = day.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

            long count = events.stream().filter(e -> e.getStart().toLocalDate().equals(day)).count();
            String stars = "*".repeat((int) count);

            String color = "";
            if (day.equals(LocalDate.now())) color = ANSI_BLUE;
            else if (day.getDayOfWeek() == DayOfWeek.SATURDAY || day.getDayOfWeek() == DayOfWeek.SUNDAY)
                color = ANSI_RED;

            sb.append(color)
            .append(String.format("%-3s\t%s\t%s", label, dateStr, stars))
            .append(ANSI_RESET)
            .append("\n");
        }

        return sb.toString();
    }


    /**
     * Displays a month calendar highlighting the number of events per day.
     *
     * @return A formatted string representing the monthly view.
     */
    public String viewMonth() {
        YearMonth yearMonth = YearMonth.from(currentDate);
        StringBuilder sb = new StringBuilder();
        sb.append("==== Monthly View ====\n");
        sb.append(yearMonth.getMonth()).append(" ").append(yearMonth.getYear()).append("\n\n");
        sb.append("Mo\tTu\tWe\tTh\tFr\tSa\tSu\n");

        LocalDate firstOfMonth = yearMonth.atDay(1);
        int firstDayOfWeek = firstOfMonth.getDayOfWeek().getValue(); 

        for (int i = 1; i < firstDayOfWeek; i++) {
            sb.append("\t");
        }

        int daysInMonth = yearMonth.lengthOfMonth();
        for (int day = 1; day <= daysInMonth; day++) {
            LocalDate thisDay = yearMonth.atDay(day);

            String color = "";
            if (thisDay.equals(LocalDate.now())) color = ANSI_BLUE;
            else if (thisDay.getDayOfWeek() == DayOfWeek.SATURDAY || thisDay.getDayOfWeek() == DayOfWeek.SUNDAY)
                color = ANSI_RED;

            long count = events.stream().filter(e -> e.getStart().toLocalDate().equals(thisDay)).count();
            String stars = "*".repeat((int) count);
            sb.append(String.format("%s%2d%s%s\t", color, day, stars, ANSI_RESET));

            if (thisDay.getDayOfWeek() == DayOfWeek.SUNDAY) {
                sb.append("\n");
            }
        }

        sb.append("\n");
        return sb.toString();
    }

    /**
     * Moves the calendar to the next month.
     */
    public void nextMonth() {
        currentDate = currentDate.plusMonths(1);
    }

    /**
     * Moves the calendar to the previous month.
     */
    public void previousMonth() {
        currentDate = currentDate.minusMonths(1);
    }

    /**
     * Moves the calendar to the next week.
     */
    public void nextWeek() {
        currentDate = currentDate.plusWeeks(1);
    }

    /**
     * Moves the calendar to the previous week.
     */
    public void previousWeek() {
        currentDate = currentDate.minusWeeks(1);
    }
}

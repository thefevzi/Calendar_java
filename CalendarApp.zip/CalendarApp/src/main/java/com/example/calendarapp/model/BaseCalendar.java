package com.example.calendarapp.model;

import java.io.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import com.example.calendarapp.model.Event.EventCategory;

/**
 * BaseCalendar manages the scheduling, storage, and display of calendar events.
 * It provides day/week/month views and supports persistence via CSV.
 */
public class BaseCalendar {

    // ANSI formatting codes for colored terminal output
    private static final String ANSI_RESET = "\u001B[0m";
    private static final String ANSI_RED = "\u001B[31m";
    private static final String ANSI_BLUE = "\u001B[34m";

    // Formatter for displaying dates
    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private LocalDate currentDate;
    private final List<Event> events = new ArrayList<>();

    /**
     * Constructs a BaseCalendar and optionally loads events from a CSV file.
     *
     * @param csvFile The file to load events from. If null or doesn't exist, nothing is loaded.
     */
    public BaseCalendar(File csvFile) {
        this.currentDate = LocalDate.now();
        if (csvFile != null && csvFile.exists()) {
            loadFromCSV(csvFile);
        }
    }

    /**
     * Sets the current working date of the calendar.
     *
     * @param date the date to set as current
     */
    public void setDate(LocalDate date) {
        this.currentDate = date;
    }

    /**
     * Gets the current working date of the calendar.
     *
     * @return the current LocalDate
     */
    public LocalDate getCurrentDate() {
        return this.currentDate;
    }

    /**
     * Adds a new event to the calendar.
     *
     * @param event the event to add
     */
    public void addEvent(Event event) {
        events.add(event);
    }

    /**
     * Gets all events currently in the calendar.
     *
     * @return a list of events
     */
    public List<Event> getEvents() {
        return events;
    }

    /**
     * Deletes an event by its ID.
     *
     * @param id the ID of the event to delete
     * @return true if the event was found and deleted, false otherwise
     */
    public boolean deleteEvent(int id) {
        return events.removeIf(e -> e.getId() == id);
    }

    /**
     * Retrieves all events of a specific category.
     *
     * @param category the event category
     * @return list of events matching the category
     */
    public List<Event> getEventsByCategory(EventCategory category) {
        List<Event> filtered = new ArrayList<>();
        for (Event e : events) {
            if (e.getCategory() == category) {
                filtered.add(e);
            }
        }
        return filtered;
    }

    /**
     * Calculates the total duration in minutes for events in a given category.
     *
     * @param category the event category
     * @return total time in minutes
     */
    public long totalTimeByCategory(EventCategory category) {
        return getEventsByCategory(category).stream()
            .mapToLong(e -> Duration.between(e.getStart(), e.getEnd()).toMinutes())
            .sum();
    }

    /**
     * Retrieves an event by its ID.
     *
     * @param id the event ID
     * @return the matching event or null if not found
     */
    public Event getEventById(int id) {
        return events.stream().filter(e -> e.getId() == id).findFirst().orElse(null);
    }

    /**
     * Updates an event by replacing it with new data.
     *
     * @param id       ID of the event to edit
     * @param title    new title
     * @param desc     new description
     * @param category new category
     * @param start    new start time
     * @param end      new end time
     * @param location new location
     * @return true if the event was found and updated
     */
    public boolean editEvent(int id, String title, String desc, EventCategory category,
                             LocalDateTime start, LocalDateTime end, String location) {
        for (int i = 0; i < events.size(); i++) {
            if (events.get(i).getId() == id) {
                events.set(i, new Event(id, title, desc, category, start, end, location));
                return true;
            }
        }
        return false;
    }

    /**
     * Saves all events to a specified CSV file.
     *
     * @param file the target file
     */
    public void saveToCSV(File file) {
        File parentDir = file.getParentFile();
        if (parentDir != null && !parentDir.exists()) {
            parentDir.mkdirs();
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            for (Event e : events) {
                writer.write(e.toCSV());
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Failed to save events: " + e.getMessage());
        }
    }

    /**
     * Loads events from a CSV file.
     *
     * @param file the file to load from
     */
    private void loadFromCSV(File file) {
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                events.add(Event.fromCSV(line));
            }
        } catch (IOException e) {
            System.err.println("Failed to load events: " + e.getMessage());
        }
    }

    /**
     * Displays all events scheduled for the current day.
     *
     * @return formatted string of events
     */
    public String viewDay() {
        StringBuilder sb = new StringBuilder();
        sb.append("==== Daily View ====\n");
        sb.append("Date: ").append(colorize(currentDate.format(DATE_FORMAT), ANSI_BLUE)).append("\n\n");

        boolean hasEvents = false;
        for (Event event : events) {
            if (isEventOnDate(event, currentDate)) {
                sb.append(event).append("\n");
                hasEvents = true;
            }
        }

        if (!hasEvents) {
            sb.append("No events scheduled for this day.\n");
        }

        return sb.toString();
    }

    /**
     * Displays a summary view of the current week with event counts per day.
     *
     * @return formatted weekly summary
     */
    public String viewWeek() {
        LocalDate startOfWeek = currentDate.with(DayOfWeek.MONDAY);
        StringBuilder sb = new StringBuilder();
        sb.append("==== Weekly View ====\n");
        sb.append("Week: ")
            .append(startOfWeek.format(DATE_FORMAT)).append(" to ")
            .append(startOfWeek.plusDays(6).format(DATE_FORMAT)).append("\n\n");

        for (int i = 0; i < 7; i++) {
            LocalDate day = startOfWeek.plusDays(i);
            String label = day.getDayOfWeek().toString().substring(0, 3);
            String dateStr = day.format(DATE_FORMAT);
            String stars = "*".repeat((int) countEventsOn(day));
            String color = getColorForDate(day);

            sb.append(color)
              .append(String.format("%-3s\t%s\t%s", label, dateStr, stars))
              .append(ANSI_RESET)
              .append("\n");
        }

        return sb.toString();
    }

    /**
     * Displays a calendar-style view of the current month with event markers.
     *
     * @return formatted monthly view
     */
    public String viewMonth() {
        YearMonth yearMonth = YearMonth.from(currentDate);
        LocalDate firstOfMonth = yearMonth.atDay(1);
        int firstDayOfWeek = firstOfMonth.getDayOfWeek().getValue();

        StringBuilder sb = new StringBuilder();
        sb.append("==== Monthly View ====\n");
        sb.append(yearMonth.getMonth()).append(" ").append(yearMonth.getYear()).append("\n\n");
        sb.append("Mo\tTu\tWe\tTh\tFr\tSa\tSu\n");

        for (int i = 1; i < firstDayOfWeek; i++) {
            sb.append("\t");
        }

        int daysInMonth = yearMonth.lengthOfMonth();
        for (int day = 1; day <= daysInMonth; day++) {
            LocalDate thisDay = yearMonth.atDay(day);
            String color = getColorForDate(thisDay);
            String stars = "*".repeat((int) countEventsOn(thisDay));
            sb.append(String.format("%s%2d%s%s\t", color, day, stars, ANSI_RESET));

            if (thisDay.getDayOfWeek() == DayOfWeek.SUNDAY) {
                sb.append("\n");
            }
        }

        sb.append("\n");
        return sb.toString();
    }

    /**
     * Moves the calendar view to the next month.
     */
    public void nextMonth() {
        currentDate = currentDate.plusMonths(1);
    }

    /**
     * Moves the calendar view to the previous month.
     */
    public void previousMonth() {
        currentDate = currentDate.minusMonths(1);
    }

    /**
     * Moves the calendar view to the next week.
     */
    public void nextWeek() {
        currentDate = currentDate.plusWeeks(1);
    }

    /**
     * Moves the calendar view to the previous week.
     */
    public void previousWeek() {
        currentDate = currentDate.minusWeeks(1);
    }

    /**
     * Checks if an event occurs on a specific date.
     *
     * @param e    the event
     * @param date the date to check
     * @return true if the event starts on the given date
     */
    private boolean isEventOnDate(Event e, LocalDate date) {
        return e.getStart().toLocalDate().equals(date);
    }

    /**
     * Counts the number of events on a specific date.
     *
     * @param date the date to check
     * @return number of events on that date
     */
    private long countEventsOn(LocalDate date) {
        return events.stream().filter(e -> isEventOnDate(e, date)).count();
    }

    /**
     * Gets the ANSI color code for a given date.
     * Weekends are red, today is blue.
     *
     * @param date the date to colorize
     * @return the ANSI color code string
     */
    private String getColorForDate(LocalDate date) {
        if (date.equals(LocalDate.now())) return ANSI_BLUE;
        if (date.getDayOfWeek() == DayOfWeek.SATURDAY || date.getDayOfWeek() == DayOfWeek.SUNDAY) return ANSI_RED;
        return "";
    }

    /**
     * Wraps a string with ANSI color codes.
     *
     * @param text      the text to color
     * @param colorCode the ANSI color code
     * @return the colored string
     */
    private String colorize(String text, String colorCode) {
        return colorCode + text + ANSI_RESET;
    }
}

package com.example.calendarapp.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Represents a calendar event with details such as title, time, category, and location.
 */
public class Event {

    /**
     * Enum representing various categories an event can belong to.
     */
    public enum EventCategory {
        WORK,
        PERSONAL,
        HEALTH,
        EDUCATION,
        SOCIAL,
        OTHER;
    }

    private String title;
    private String description;
    private LocalDateTime start;
    private LocalDateTime end;
    private static int nextId = 1; 
    private final int id;
    private EventCategory category;
    private String location;
    private static final String ANSI_RESET = "\u001B[0m";
    private static final String ANSI_CYAN = "\u001B[36m";

    /**
     * Constructs a new Event with an auto-generated ID.
     *
     * @param title       The title of the event.
     * @param description The event's description.
     * @param category    The category of the event.
     * @param start       The start date and time.
     * @param end         The end date and time.
     * @param location    The location of the event.
     */
    public Event(String title, String description, EventCategory category, LocalDateTime start, LocalDateTime end, String location) {
        this.id = nextId++;
        this.title = title;
        this.description = description;
        this.category = category;
        this.start = start;
        this.end = end;
        this.location = location;
    }

    /**
     * Constructs an Event with a specified ID (used when loading from CSV).
     *
     * @param id          The unique identifier for the event.
     * @param title       The title of the event.
     * @param description The event's description.
     * @param category    The category of the event.
     * @param start       The start date and time.
     * @param end         The end date and time.
     * @param location    The location of the event.
     */
    public Event(int id, String title, String description, EventCategory category, LocalDateTime start, LocalDateTime end, String location) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.category = category;
        this.start = start;
        this.end = end;
        this.location = location;
        if (id >= nextId) {
            nextId = id + 1;
        }
    }

    /**
     * Gets the title of the event.
     *
     * @return The event title.
     */
    public String getTitle() {
        return title;
    }

    /**
     * Gets the description of the event.
     *
     * @return The event description.
     */
    public String getDescription() {
        return description;
    }

    /**
     * Gets the start date and time of the event.
     *
     * @return The start LocalDateTime.
     */
    public LocalDateTime getStart() {
        return start;
    }

    /**
     * Gets the end date and time of the event.
     *
     * @return The end LocalDateTime.
     */
    public LocalDateTime getEnd() {
        return end;
    }

    /**
     * Gets the unique ID of the event.
     *
     * @return The event ID.
     */
    public int getId() {
        return id;
    }

    /**
     * Gets the category of the event.
     *
     * @return The event category.
     */
    public EventCategory getCategory() {
        return category;
    }

    /**
     * Gets the location of the event.
     *
     * @return The event location.
     */
    public String getLocation() {
        return location;
    }

    /**
     * Returns a formatted string representation of the event.
     *
     * @return A string of the event details.
     */
    @Override
    public String toString() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        return String.format("%s[%d] %s%s: %s | %s - %s | %s | %s",
                ANSI_CYAN, id, title, ANSI_RESET,
                description,
                start.format(formatter),
                end.format(formatter),
                category,
                location);
    }

    /**
     * Serializes the event.
     *
     * @return The CSV representation of the event.
     */
    public String toCSV() {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        return String.join("|",
            String.valueOf(id),
            title.replace("|", "/"),
            description.replace("|", "/"),
            category.name(),
            start.format(fmt),
            end.format(fmt),
            location.replace("|", "/")
        );
    }

    /**
     * Deserializes a CSV string into an Event object.
     *
     * @param line The CSV line representing an event.
     * @return A new Event object.
     */
    public static Event fromCSV(String line) {
        String[] parts = line.split("\\|");
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        
        int id = Integer.parseInt(parts[0]);
        String title = parts[1];
        String description = parts[2]; 
        EventCategory category = EventCategory.valueOf(parts[3]);
        LocalDateTime start = LocalDateTime.parse(parts[4], fmt);
        LocalDateTime end = LocalDateTime.parse(parts[5], fmt);
        String location = parts.length > 6 ? parts[6] : "N/A";

        return new Event(id, title, description, category, start, end, location);
    }
}

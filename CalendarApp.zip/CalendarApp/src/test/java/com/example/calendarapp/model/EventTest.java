package com.example.calendarapp.model;

import org.junit.jupiter.api.Test;
import java.time.LocalDateTime;
import static org.junit.jupiter.api.Assertions.*;

public class EventTest {

    @Test
    public void testToAndFromCSV() {
        Event original = new Event(10, "Title", "Desc", Event.EventCategory.SOCIAL,
            LocalDateTime.of(2025, 1, 1, 14, 0),
            LocalDateTime.of(2025, 1, 1, 15, 30),
            "Cafe");

        String csv = original.toCSV();
        Event reconstructed = Event.fromCSV(csv);

        assertEquals(original.getId(), reconstructed.getId());
        assertEquals(original.getTitle(), reconstructed.getTitle());
        assertEquals(original.getStart(), reconstructed.getStart());
    }

    @Test
    public void testEventConstructorAndGetters() {
        LocalDateTime start = LocalDateTime.of(2025, 6, 1, 9, 0);
        LocalDateTime end = LocalDateTime.of(2025, 6, 1, 10, 0);

        Event event = new Event("Test Event", "Description", Event.EventCategory.HEALTH, start, end, "Park");

        assertNotNull(event.getId());
        assertEquals("Test Event", event.getTitle());
        assertEquals("Description", event.getDescription());
        assertEquals(Event.EventCategory.HEALTH, event.getCategory());
        assertEquals(start, event.getStart());
        assertEquals(end, event.getEnd());
        assertEquals("Park", event.getLocation());
    }

    @Test
    public void testToStringFormatContainsKeyParts() {
        Event event = new Event("Yoga", "Morning session", Event.EventCategory.HEALTH,
            LocalDateTime.of(2025, 6, 2, 7, 0),
            LocalDateTime.of(2025, 6, 2, 8, 0),
            "Studio");

        String output = event.toString();
        assertTrue(output.contains("Yoga"));
        assertTrue(output.contains("Morning session"));
        assertTrue(output.contains("HEALTH"));
        assertTrue(output.contains("Studio"));
        assertTrue(output.contains("\u001B[36m"));
    }

    @Test
    public void testToCSVHandlesPipesProperly() {
        Event event = new Event(99, "Pipe|Title", "Pipe|Desc", Event.EventCategory.OTHER,
            LocalDateTime.of(2025, 7, 1, 12, 0),
            LocalDateTime.of(2025, 7, 1, 13, 0),
            "Location|Here");

        String csv = event.toCSV();
        assertFalse(csv.contains("|Title")); 
        assertFalse(csv.contains("|Desc"));
        assertFalse(csv.contains("|Here"));

        assertTrue(csv.contains("Pipe/Title")); 
        assertTrue(csv.contains("Pipe/Desc"));
        assertTrue(csv.contains("Location/Here"));
    }

    @Test
    public void testFromCSVHandlesMissingLocation() {
        String line = "101|Event Title|Desc|WORK|22/05/2025 09:00|22/05/2025 10:00";
        Event event = Event.fromCSV(line);

        assertEquals("N/A", event.getLocation());
        assertEquals(101, event.getId());
        assertEquals("Event Title", event.getTitle());
        assertEquals(Event.EventCategory.WORK, event.getCategory());
    }
}

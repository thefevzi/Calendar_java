package com.example.calendarapp.model;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.example.calendarapp.model.Event.EventCategory;

public class BaseCalendarTest {

    private BaseCalendar calendar;

    @BeforeEach
    public void setUp() {
        calendar = new BaseCalendar();
    }

    @Test
    public void testAddEvent() {
        Event event = new Event("Title1", "Desc1", EventCategory.WORK,
            LocalDateTime.of(2025, 5, 23, 10, 0),
            LocalDateTime.of(2025, 5, 23, 11, 0),
            "Loc");

        calendar.addEvent(event);

        List<Event> events = calendar.getEvents();
        assertEquals(1, events.size());
        assertEquals("Title1", events.get(0).getTitle());
    }

    @Test
    public void testSetAndGetDate() {
        LocalDate date = LocalDate.of(2025, 12, 25);
        calendar.setDate(date);
        assertEquals(date, calendar.getCurrentDate());
    }

    @Test
    public void testGetEventsByCategory() {
        Event event1 = new Event("Workout", "Gym session", EventCategory.HEALTH,
            LocalDateTime.now(), LocalDateTime.now().plusHours(1), "Gym");
        Event event2 = new Event("Class", "Math lecture", EventCategory.EDUCATION,
            LocalDateTime.now(), LocalDateTime.now().plusHours(2), "School");

        calendar.addEvent(event1);
        calendar.addEvent(event2);

        List<Event> healthEvents = calendar.getEventsByCategory(EventCategory.HEALTH);
        assertEquals(1, healthEvents.size());
        assertEquals("Workout", healthEvents.get(0).getTitle());
    }

    @Test
    public void testEditEvent() {
        Event event = new Event("Old Title", "Old Desc", EventCategory.OTHER,
            LocalDateTime.of(2025, 5, 24, 9, 0),
            LocalDateTime.of(2025, 5, 24, 10, 0), "Old Place");

        calendar.addEvent(event);
        boolean result = calendar.editEvent(event.getId(), "New Title", "New Desc",
            EventCategory.WORK, LocalDateTime.of(2025, 5, 24, 10, 0),
            LocalDateTime.of(2025, 5, 24, 11, 0), "New Place");

        assertTrue(result);
        Event edited = calendar.getEventById(event.getId());
        assertEquals("New Title", edited.getTitle());
        assertEquals(EventCategory.WORK, edited.getCategory());
    }

    @Test
    public void testTotalTimeByCategory() {
        calendar.addEvent(new Event("Work 1", "", EventCategory.WORK,
            LocalDateTime.of(2025, 5, 22, 9, 0),
            LocalDateTime.of(2025, 5, 22, 10, 0), "Office"));

        calendar.addEvent(new Event("Work 2", "", EventCategory.WORK,
            LocalDateTime.of(2025, 5, 22, 11, 0),
            LocalDateTime.of(2025, 5, 22, 12, 30), "Office"));

        long totalMinutes = calendar.totalTimeByCategory(EventCategory.WORK);
        assertEquals(150, totalMinutes);
    }

    @Test
    public void testGetEventByIdNotFound() {
        assertNull(calendar.getEventById(999));
    }

    @Test
    public void testEditEventFailsOnInvalidId() {
        boolean result = calendar.editEvent(999, "New", "Desc", EventCategory.WORK,
            LocalDateTime.now(), LocalDateTime.now().plusHours(1), "Location");
        assertFalse(result);
    }

    @Test
    public void testViewDayIncludesEvent() {
        LocalDateTime now = LocalDateTime.now();
        Event event = new Event("Meeting", "Discuss Q2", EventCategory.WORK, now, now.plusHours(1), "Room 1");
        calendar.addEvent(event);
        calendar.setDate(now.toLocalDate());

        String output = calendar.viewDay();
        assertTrue(output.contains("Meeting"));
        assertTrue(output.contains("Discuss Q2"));
    }

    @Test
    public void testViewWeekIncludesCurrentDate() {
        calendar.setDate(LocalDate.now());
        String weekView = calendar.viewWeek();

        String todayStr = LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        assertTrue(weekView.contains(todayStr));
    }

    @Test
    public void testViewMonthIncludesStarsForEvents() {
        LocalDateTime date = LocalDateTime.of(2025, 5, 10, 14, 0);
        Event event = new Event("Test", "Month view test", EventCategory.OTHER, date, date.plusHours(1), "Home");
        calendar.addEvent(event);
        calendar.setDate(LocalDate.of(2025, 5, 1));

        String monthView = calendar.viewMonth();
        assertTrue(monthView.contains("10*"));
    }

    @Test
    public void testNavigationMethods() {
        LocalDate start = calendar.getCurrentDate();

        calendar.nextMonth();
        assertEquals(start.plusMonths(1), calendar.getCurrentDate());

        calendar.previousMonth();
        assertEquals(start, calendar.getCurrentDate());

        calendar.nextWeek();
        assertEquals(start.plusWeeks(1), calendar.getCurrentDate());

        calendar.previousWeek();
        assertEquals(start, calendar.getCurrentDate());
    }
}

# Calendar

A simple command-line calendar and event management tool written in Java. 

Allows users to: 
- view their schedules by day, week, or month,
- add, delete and edit events, 
- track time spent on activities,
- and manage events by category.

## Requirements
- Java 17 or higher
- Apache Maven

## How to run
```bash
mvn exec:java
```

## Usage
Upon starting, you'll see a summary of the week and available commands.

- **view-day** — View all events for the current day.  
- **view-week** — Weekly summary with event count.  
- **view-month** — Monthly calendar with event count.  
- **next-month** / **prev-month** — Navigate calendar by month.  
- **next-week** / **prev-week** — Navigate calendar by week.  
- **set-date dd/MM/yyyy** — Set the current date. 
- **add-event** — Add a new event.  
- **edit-event <id>** — Edit an existing event by ID.  
- **view-event <id>** — View details of an event by ID.  
- **list-events** — List all events.  
- **events-by-category <CATEGORY>** — Filter events by category.  
- **track-time <CATEGORY>** — Track total time spent per category.
- **delete-event <id>** — Delete an existing event by ID.
- **exit** — Save changes and exit the app.

### Example
```bash
> add-event
Title: Meeting with Team
Description: Sprint planning
Category: WORK
Start (dd/MM/yyyy HH:mm): 23/05/2025 10:00
End (dd/MM/yyyy HH:mm): 23/05/2025 11:00
Location: Conference Room
Event added.
```

## Data Storage
All events are stored in a sub-folder in the user home folder.

Events are automatically saved when you:
- Add/edit/delete an event, or
- Exit the application.